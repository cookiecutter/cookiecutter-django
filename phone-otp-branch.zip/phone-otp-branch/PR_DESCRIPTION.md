# feat: add `phone` option to `username_type` — phone number + OTP authentication

## Summary

Adds `phone` as a third choice for `username_type` (alongside `username` and `email`).

When selected, the generated project uses **phone number + OTP** as the primary
authentication method, powered by **django-allauth's native phone support**
(available since allauth 65.x). Passwords remain in the model but are **unusable
by default** — users can optionally set one later.

---

## New prompt behaviour

```
Select username_type:
1 - username
2 - email
3 - phone          ← NEW
Choose from 1, 2, 3 [1]: 3
```

---

## What changes per-file

### `cookiecutter.json`
```json
- "username_type": ["username", "email"],
+ "username_type": ["username", "email", "phone"],
```

---

### `users/models.py`
New `phone` branch added. The generated `User` model gets:

| Field | Detail |
|---|---|
| `phone` | `CharField(max_length=17, unique=True)` — stored in E.164 format |
| `phone_verified` | `BooleanField(default=False)` — set to `True` after OTP verified |
| `email` | `EmailField(blank=True)` — optional for phone-auth users |
| `username` | `None` — removed |
| `USERNAME_FIELD` | `"phone"` |
| `save()` | Calls `set_unusable_password()` for new users automatically |

---

### `users/managers.py`
New `PhoneUserManager` branch:
- `create_user(phone, password=None)` — defaults to unusable password
- `create_superuser(phone, password)` — requires a real password for admin access

---

### `users/adapters.py`  ← **most important new file**
allauth 65.x delegates all phone storage and SMS delivery to the project adapter.
The generated `AccountAdapter` implements:

| Method | Does |
|---|---|
| `get_phone(user)` | Returns `(phone, verified)` tuple |
| `set_phone(user, phone, verified)` | Saves to `User.phone` + `User.phone_verified` |
| `set_phone_verified(user, phone)` | Marks phone as verified after OTP check |
| `get_user_by_phone(phone)` | Lookup by phone for login |
| `send_verification_code_sms(user, phone, code)` | **Stub** — developer fills in SMS provider |
| `send_unknown_account_sms(phone)` | Enumeration-prevention SMS stub |

`send_verification_code_sms()` includes commented-out examples for **Twilio** and
**Vonage**, and logs the code at `WARNING` level during development so the OTP flow
works without a real SMS provider.

---

### `config/settings/base.py`
New conditional allauth block for `phone`:

```python
# Generated output when username_type == "phone":
ACCOUNT_LOGIN_METHODS = {"phone"}
ACCOUNT_SIGNUP_FIELDS = ["phone*"]
ACCOUNT_PHONE_VERIFICATION_ENABLED = True
ACCOUNT_PHONE_VERIFICATION_SUPPORTS_RESEND = True
ACCOUNT_PHONE_VERIFICATION_TIMEOUT = env.int("ACCOUNT_PHONE_VERIFICATION_TIMEOUT", default=900)
```

---

### `users/forms.py`, `users/admin.py`, `users/views.py`, `users/urls.py`
All updated with `phone` branches. Notable:
- Admin shows `phone`, `phone_verified`, optional `email`; password fields remain
  but are labeled as optional
- Detail/redirect URLs use `pk` (same as email mode) since `username` is absent

---

### `templates/account/phone/`  ← **new directory**
Two new allauth template overrides:
- `verification_code.html` — OTP entry form with resend link
- `signup.html` — phone-only signup (no password field)

Cleaned up by `post_gen_project.py` when `username_type != "phone"`.

---

### `hooks/post_gen_project.py`
Two-line change:

```python
# Before:
if "{{ cookiecutter.username_type }}" != "email":
    remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))

# After:
if "{{ cookiecutter.username_type }}" not in ("email", "phone"):
    remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))

# New block added after:
if "{{ cookiecutter.username_type }}" != "phone":
    import shutil as _shutil
    _phone_tpl = Path("{{ cookiecutter.project_slug }}/templates/account/phone")
    if _phone_tpl.exists():
        _shutil.rmtree(_phone_tpl)
```

---

### `users/tests/`
- `factories.py` — `UserFactory` for phone uses `phone=factory.Sequence(...)`, no password
- `test_models.py` — tests for unusable-password default, uniqueness, superuser password
- `test_adapters.py` — tests for all 5 adapter phone methods + warning log

---

## What the developer does after generation

```bash
# 1. Pick an SMS provider — edit users/adapters.py
#    Uncomment the Twilio or Vonage block in send_verification_code_sms()

# 2. Add credentials to .envs/.local/.django
TWILIO_ACCOUNT_SID=ACxxx
TWILIO_AUTH_TOKEN=xxx
TWILIO_PHONE_NUMBER=+15005550006

# 3. Install the provider package
uv add twilio       # or: uv add vonage

# 4. Run migrations
python manage.py migrate

# 5. Create a superuser (password required for admin)
python manage.py createsuperuser
# Phone: +12125551234
# Password: (required — used for Django admin login)
```

**During development without a real SMS provider:** OTP codes are printed to the
Django dev server log at `WARNING` level. No SMS setup needed to test the flow.

---

## Design decisions

- **Password is optional, not removed.** `AbstractUser` keeps the password field.
  New users get `set_unusable_password()`. This means `has_usable_password()` → `False`
  until they explicitly set one, but the door is open for password login too.
- **No new dependency is required.** `django-phonenumber-field` is recommended
  (comment in requirements) but the model works with plain `CharField` so developers
  can add it when ready.
- **allauth's native phone support** is used instead of a custom backend — this
  means rate limiting, OTP expiry, resend, and enumeration prevention all come
  for free from allauth.

---

## Checklist

- [x] `cookiecutter.json` updated
- [x] `users/models.py` — phone branch
- [x] `users/managers.py` — phone manager
- [x] `users/adapters.py` — all 5 allauth phone adapter methods + SMS stubs
- [x] `users/forms.py` — phone branch
- [x] `users/admin.py` — phone fields, optional password in add form
- [x] `users/views.py` — pk-based URLs
- [x] `users/urls.py` — conditional username vs pk URL pattern
- [x] `config/settings/base.py` — allauth phone settings block
- [x] `templates/account/phone/` — OTP entry & signup templates
- [x] `hooks/post_gen_project.py` — preserve managers.py, clean phone templates
- [x] `users/tests/factories.py` — phone factory
- [x] `users/tests/test_models.py` — unusable password, uniqueness tests
- [x] `users/tests/test_adapters.py` — adapter method tests
- [x] `.envs/.local/.django` — SMS provider var comments
