"""
PATCH INSTRUCTIONS for hooks/pre_gen_project.py
================================================

Add this block BEFORE the final `if __name__ == "__main__"` section
(or at the end of the existing validation logic):

--- ADD ---
# Phone option: warn if username + email mode is combined with phone
# (should never happen given the cookiecutter.json choices, but belt-and-braces)
USERNAME_TYPE = "{{ cookiecutter.username_type }}"
if USERNAME_TYPE not in {"username", "email", "phone"}:
    print(
        f"ERROR: username_type '{USERNAME_TYPE}' is not supported. "
        "Choose one of: username, email, phone"
    )
    sys.exit(1)
--- END ADD ---
"""
