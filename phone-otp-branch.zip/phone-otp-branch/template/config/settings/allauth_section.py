# django-allauth
# ------------------------------------------------------------------------------
ACCOUNT_ALLOW_REGISTRATION = env.bool("DJANGO_ACCOUNT_ALLOW_REGISTRATION", default=True)
# https://docs.allauth.org/en/latest/account/configuration.html
{%- if cookiecutter.username_type == "username" %}
ACCOUNT_LOGIN_METHODS = {"username"}
ACCOUNT_SIGNUP_FIELDS = ["username*", "email*", "password1*", "password2*"]
{%- elif cookiecutter.username_type == "email" %}
ACCOUNT_LOGIN_METHODS = {"email"}
ACCOUNT_SIGNUP_FIELDS = ["email*", "password1*", "password2*"]
{%- elif cookiecutter.username_type == "phone" %}
# Phone + OTP is the primary auth method.
# Password is supported but optional — new users are created with
# an unusable password unless they explicitly set one.
ACCOUNT_LOGIN_METHODS = {"phone"}
ACCOUNT_SIGNUP_FIELDS = ["phone*"]
# Enable phone number verification via OTP
ACCOUNT_PHONE_VERIFICATION_ENABLED = True
ACCOUNT_PHONE_VERIFICATION_SUPPORTS_RESEND = True
# How long (seconds) before the OTP expires — default 900 (15 min)
ACCOUNT_PHONE_VERIFICATION_TIMEOUT = env.int(
    "ACCOUNT_PHONE_VERIFICATION_TIMEOUT", default=900
)
{%- endif %}
# https://docs.allauth.org/en/latest/account/configuration.html
ACCOUNT_ADAPTER = "{{ cookiecutter.project_slug }}.users.adapters.AccountAdapter"
# https://docs.allauth.org/en/latest/account/forms.html
ACCOUNT_FORMS = {"signup": "{{ cookiecutter.project_slug }}.users.forms.UserSignupForm"}
# https://docs.allauth.org/en/latest/socialaccount/configuration.html
SOCIALACCOUNT_ADAPTER = "{{ cookiecutter.project_slug }}.users.adapters.SocialAccountAdapter"
# https://docs.allauth.org/en/latest/socialaccount/configuration.html
SOCIALACCOUNT_FORMS = {"signup": "{{ cookiecutter.project_slug }}.users.forms.UserSocialSignupForm"}
{%- if cookiecutter.username_type == "phone" %}

# ── SMS Provider credentials (fill in your .env) ────────────────────────────
# These are placeholders — adjust the variable names to match your provider.
# See users/adapters.py → AccountAdapter.send_verification_code_sms() for
# the implementation.
#
# Twilio:
# TWILIO_ACCOUNT_SID = env("TWILIO_ACCOUNT_SID", default="")
# TWILIO_AUTH_TOKEN  = env("TWILIO_AUTH_TOKEN", default="")
# TWILIO_PHONE_NUMBER = env("TWILIO_PHONE_NUMBER", default="")
#
# Vonage / Nexmo:
# VONAGE_API_KEY    = env("VONAGE_API_KEY", default="")
# VONAGE_API_SECRET = env("VONAGE_API_SECRET", default="")
# VONAGE_BRAND_NAME = env("VONAGE_BRAND_NAME", default="{{ cookiecutter.project_name }}")
{%- endif %}
