from allauth.account.forms import SignupForm
from allauth.socialaccount.forms import SignupForm as SocialSignupForm
from django.contrib.auth import forms as admin_forms
from django.contrib.auth import get_user_model
{%- if cookiecutter.username_type == "email" %}
from django.forms import EmailField
{%- elif cookiecutter.username_type == "phone" %}
from django.forms import CharField
from django.forms import EmailField
{%- endif %}
from django.utils.translation import gettext_lazy as _

User = get_user_model()


class UserAdminChangeForm(admin_forms.UserChangeForm):
    class Meta(admin_forms.UserChangeForm.Meta):
        model = User
{%- if cookiecutter.username_type == "email" %}
        field_classes = {"email": EmailField}
{%- elif cookiecutter.username_type == "phone" %}
        fields = "__all__"
{%- endif %}


class UserAdminCreationForm(admin_forms.UserCreationForm):
    """
    Form for User Creation in the Admin Area.
    To change user signup, see UserSignupForm and UserSocialSignupForm.
    """

    class Meta(admin_forms.UserCreationForm.Meta):
        model = User
{%- if cookiecutter.username_type == "email" %}
        fields = ("email",)
        field_classes = {"email": EmailField}
        error_messages = {
            "email": {"unique": _("This email has already been taken.")},
        }
{%- elif cookiecutter.username_type == "phone" %}
        fields = ("phone",)
        error_messages = {
            "phone": {"unique": _("This phone number has already been taken.")},
        }
{%- else %}
        error_messages = {
            "username": {"unique": _("This username has already been taken.")},
        }
{%- endif %}


class UserSignupForm(SignupForm):
    """
    Form that will be rendered on a user sign up section/screen.
    Default fields will be taken from 'allauth.account.forms.SignupForm'
    Check UserSocialSignupForm for accounts created from social.
    """
{%- if cookiecutter.username_type == "phone" %}
    # allauth handles the phone field via ACCOUNT_SIGNUP_FIELDS.
    # Add any extra fields you need at signup below, e.g. name:
    # name = CharField(max_length=255, required=False, label=_("Name"))
    pass
{%- endif %}


class UserSocialSignupForm(SocialSignupForm):
    """
    Renders the form when user has signed up using social accounts.
    Default fields will be taken from 'allauth.socialaccount.forms.SignupForm'
    Check UserSignupForm for regular signup.
    """
