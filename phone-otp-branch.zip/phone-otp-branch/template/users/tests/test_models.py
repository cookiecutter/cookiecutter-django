{%- if cookiecutter.username_type == "phone" %}
import pytest

from {{ cookiecutter.project_slug }}.users.models import User
from {{ cookiecutter.project_slug }}.users.tests.factories import UserFactory


class TestUserModel:
    def test_user_get_absolute_url(self, user: User):
        assert user.get_absolute_url() == f"/users/{user.pk}/"

    def test_new_user_has_unusable_password(self):
        """Phone-auth users should start with an unusable password."""
        user = UserFactory()
        assert not user.has_usable_password()

    def test_user_with_explicit_password_is_usable(self):
        """Users can optionally have a real password."""
        user = UserFactory(password="SuperSecretPass123!")  # noqa: S106
        assert user.has_usable_password()

    def test_phone_is_unique(self, db):
        phone = "+12125552368"
        UserFactory(phone=phone)
        with pytest.raises(Exception):  # IntegrityError
            UserFactory(phone=phone)

    def test_superuser_has_usable_password(self, db):
        """Superusers need a real password for admin access."""
        user = User.objects.create_superuser(
            phone="+12125559999",
            password="AdminPass123!",  # noqa: S106
        )
        assert user.has_usable_password()
        assert user.is_superuser
{%- endif %}
