{%- if cookiecutter.username_type == "phone" %}
import pytest
from unittest.mock import patch

from {{ cookiecutter.project_slug }}.users.adapters import AccountAdapter
from {{ cookiecutter.project_slug }}.users.models import User
from {{ cookiecutter.project_slug }}.users.tests.factories import UserFactory


class TestPhoneAccountAdapter:
    """Tests for the AccountAdapter phone methods."""

    @pytest.fixture
    def adapter(self, rf):
        request = rf.get("/")
        return AccountAdapter(request)

    def test_get_phone_returns_tuple(self, adapter):
        user = UserFactory(phone="+12125551234", phone_verified=True)
        result = adapter.get_phone(user)
        assert result == ("+12125551234", True)

    def test_get_phone_returns_none_when_no_phone(self, adapter):
        # Build a user without a phone (hypothetical edge case)
        user = User.__new__(User)
        user.phone = ""
        result = adapter.get_phone(user)
        assert result is None

    def test_set_phone_updates_model(self, adapter, db):
        user = UserFactory(phone="+12125550000", phone_verified=False)
        adapter.set_phone(user, "+12125559999", True)
        user.refresh_from_db()
        assert user.phone == "+12125559999"
        assert user.phone_verified is True

    def test_set_phone_verified(self, adapter, db):
        user = UserFactory(phone="+12125550001", phone_verified=False)
        adapter.set_phone_verified(user, "+12125550001")
        user.refresh_from_db()
        assert user.phone_verified is True

    def test_get_user_by_phone_found(self, adapter, db):
        user = UserFactory(phone="+12125550002")
        found = adapter.get_user_by_phone("+12125550002")
        assert found == user

    def test_get_user_by_phone_not_found(self, adapter, db):
        result = adapter.get_user_by_phone("+19999999999")
        assert result is None

    def test_send_verification_code_sms_logs_warning(self, adapter, db, caplog):
        """Without a real SMS provider, the code should be logged as a warning."""
        import logging
        user = UserFactory()
        with caplog.at_level(logging.WARNING, logger="{{ cookiecutter.project_slug }}.users.adapters"):
            adapter.send_verification_code_sms(user, "+12125550003", "123456")
        assert "123456" in caplog.text
{%- endif %}
