{%- if cookiecutter.username_type == "phone" %}
from collections.abc import Sequence
from typing import Any

import factory
from factory import post_generation
from factory.django import DjangoModelFactory

from {{ cookiecutter.project_slug }}.users.models import User


class UserFactory(DjangoModelFactory):
    # Auto-generate unique E.164-like phone numbers for tests
    phone = factory.Sequence(lambda n: f"+1555000{n:04d}")
    phone_verified = False
    name = factory.Faker("name")
    email = factory.Faker("email")

    @post_generation
    def password(self, create: bool, extracted: Sequence[Any], **kwargs):  # noqa: FBT001
        if extracted:
            self.set_password(extracted)
            # Only save if we are not in a build (non-DB) strategy
            if create:
                self.save(update_fields=["password"])
        # Default: leave unusable password (phone-auth default)

    class Meta:
        model = User
        django_get_or_create = ["phone"]
{%- elif cookiecutter.username_type == "email" %}
from collections.abc import Sequence
from typing import Any

import factory
from factory import post_generation
from factory.django import DjangoModelFactory

from {{ cookiecutter.project_slug }}.users.models import User


class UserFactory(DjangoModelFactory):
    email = factory.Faker("email")
    name = factory.Faker("name")

    @post_generation
    def password(self, create: bool, extracted: Sequence[Any], **kwargs):  # noqa: FBT001
        password = (
            extracted
            if extracted
            else factory.Faker(
                "password",
                length=42,
                special_chars=True,
                digits=True,
                upper_case=True,
                lower_case=True,
            ).evaluate(None, None, extra={"locale": None})
        )
        self.set_password(password)

    class Meta:
        model = User
        django_get_or_create = ["email"]
{%- else %}
from collections.abc import Sequence
from typing import Any

import factory
from factory import post_generation
from factory.django import DjangoModelFactory

from {{ cookiecutter.project_slug }}.users.models import User


class UserFactory(DjangoModelFactory):
    username = factory.Faker("user_name")
    email = factory.Faker("email")
    name = factory.Faker("name")

    @post_generation
    def password(self, create: bool, extracted: Sequence[Any], **kwargs):  # noqa: FBT001
        password = (
            extracted
            if extracted
            else factory.Faker(
                "password",
                length=42,
                special_chars=True,
                digits=True,
                upper_case=True,
                lower_case=True,
            ).evaluate(None, None, extra={"locale": None})
        )
        self.set_password(password)

    class Meta:
        model = User
        django_get_or_create = ["username"]
{%- endif %}
