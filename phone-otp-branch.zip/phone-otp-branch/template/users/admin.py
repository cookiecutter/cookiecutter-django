from django.contrib import admin
from django.contrib.auth import admin as auth_admin
from django.utils.translation import gettext_lazy as _

from {{ cookiecutter.project_slug }}.users.forms import UserAdminChangeForm
from {{ cookiecutter.project_slug }}.users.forms import UserAdminCreationForm
from {{ cookiecutter.project_slug }}.users.models import User


@admin.register(User)
class UserAdmin(auth_admin.UserAdmin):
    form = UserAdminChangeForm
    add_form = UserAdminCreationForm
    fieldsets = (
        (None, {"fields": (
{%- if cookiecutter.username_type == "email" %}
            "email",
{%- elif cookiecutter.username_type == "phone" %}
            "phone",
            "phone_verified",
{%- else %}
            "username",
{%- endif %}
            "password",
        )}),
        (_("Personal info"), {"fields": ("name",
{%- if cookiecutter.username_type == "phone" %}
            "email",
{%- elif cookiecutter.username_type == "username" %}
            "email",
{%- endif %}
        )}),
        (
            _("Permissions"),
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                ),
            },
        ),
        (_("Important dates"), {"fields": ("last_login", "date_joined")}),
    )
    list_display = [
{%- if cookiecutter.username_type == "email" %}
        "email",
{%- elif cookiecutter.username_type == "phone" %}
        "phone",
        "phone_verified",
        "email",
{%- else %}
        "username",
        "email",
{%- endif %}
        "name",
        "is_superuser",
    ]
    search_fields = [
{%- if cookiecutter.username_type == "email" %}
        "email",
{%- elif cookiecutter.username_type == "phone" %}
        "phone",
        "email",
{%- else %}
        "username",
{%- endif %}
        "name",
    ]
{%- if cookiecutter.username_type == "email" %}
    ordering = ["email"]
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "password1", "password2"),
            },
        ),
    )
{%- elif cookiecutter.username_type == "phone" %}
    ordering = ["phone"]
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "phone",
                    "email",
                    "name",
                    # Password is optional for phone-auth users.
                    # Leave blank to create user with unusable password.
                    "password1",
                    "password2",
                ),
            },
        ),
    )
{%- endif %}
