"""
django-allauth adapter for {{ cookiecutter.project_name }}.
{%- if cookiecutter.username_type == "phone" %}

Phone OTP adapter: implements the four adapter methods allauth needs so that
phone numbers are stored on the User model and OTP codes can be sent via SMS.

To wire up a real SMS provider, implement `send_verification_code_sms()`.
See the inline comments for Twilio and Vonage (nexmo) examples.
{%- endif %}
"""

from django.contrib.auth import get_user_model
from django.http import HttpRequest

from allauth.account.adapter import DefaultAccountAdapter
from allauth.socialaccount.adapter import DefaultSocialAccountAdapter

{%- if cookiecutter.username_type == "phone" %}

import logging

logger = logging.getLogger(__name__)
{%- endif %}


class AccountAdapter(DefaultAccountAdapter):
    def is_open_for_signup(self, request: HttpRequest) -> bool:
        return getattr(self.request, "allow_signup", True)
{%- if cookiecutter.username_type == "phone" %}

    # ------------------------------------------------------------------ #
    # Phone number storage — allauth delegates all model I/O to here      #
    # ------------------------------------------------------------------ #

    def get_phone(self, user) -> tuple[str, bool] | None:
        """Return (phone, verified) or None if the user has no phone."""
        phone = getattr(user, "phone", None)
        if phone:
            return phone, user.phone_verified
        return None

    def set_phone(self, user, phone: str, verified: bool) -> None:
        """Persist a phone number (and its verified state) on the user."""
        user.phone = phone
        user.phone_verified = verified
        user.save(update_fields=["phone", "phone_verified"])

    def set_phone_verified(self, user, phone: str) -> None:
        """Mark the phone number as verified (called after OTP check)."""
        user.phone_verified = True
        user.save(update_fields=["phone_verified"])

    def get_user_by_phone(self, phone: str):
        """Look up a user by phone number. Returns None if not found."""
        User = get_user_model()
        try:
            return User.objects.get(phone=phone)
        except User.DoesNotExist:
            return None

    # ------------------------------------------------------------------ #
    # SMS sending                                                          #
    # ------------------------------------------------------------------ #

    def send_verification_code_sms(self, user, phone: str, code: str, **kwargs) -> None:
        """
        Send the OTP verification code to `phone` via SMS.

        Replace the body below with your chosen SMS provider.

        ── Twilio example ────────────────────────────────────────────────
        from django.conf import settings
        from twilio.rest import Client

        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        client.messages.create(
            body=f"Your {{ cookiecutter.project_name }} verification code is: {code}",
            from_=settings.TWILIO_PHONE_NUMBER,
            to=phone,
        )

        ── Vonage (nexmo) example ────────────────────────────────────────
        import vonage
        from django.conf import settings

        client = vonage.Client(
            key=settings.VONAGE_API_KEY,
            secret=settings.VONAGE_API_SECRET,
        )
        vonage.Sms(client).send_message(
            {
                "from": settings.VONAGE_BRAND_NAME,
                "to": phone.lstrip("+"),   # Vonage wants digits only
                "text": f"Your {{ cookiecutter.project_name }} verification code is: {code}",
            }
        )

        ── During development ────────────────────────────────────────────
        If you don't have an SMS provider set up yet, log the code so
        development keeps working:
        """
        # TODO: replace this with your real SMS provider call
        logger.warning(
            "send_verification_code_sms() is not implemented. "
            "OTP code for %s: %s",
            phone,
            code,
        )
        # Once you implement a provider, remove the line above and uncomment
        # one of the provider blocks shown in the docstring.

    def send_unknown_account_sms(self, phone: str, **kwargs) -> None:
        """
        Called when enumeration prevention is on and someone requests an
        OTP for a phone number that has no account. Send a neutral SMS so
        the caller cannot infer whether the number is registered.
        """
        logger.warning(
            "send_unknown_account_sms() is not implemented for phone %s.",
            phone,
        )
        # Uncomment and adapt once you have an SMS provider:
        # self._send_sms(
        #     phone,
        #     "We received a login request for this number but no account "
        #     "was found. If this was not you, please ignore this message."
        # )
{%- endif %}


class SocialAccountAdapter(DefaultSocialAccountAdapter):
    def is_open_for_signup(
        self,
        request: HttpRequest,
        sociallogin,
    ) -> bool:
        return getattr(self.request, "allow_signup", True)
