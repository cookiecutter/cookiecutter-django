{%- if cookiecutter.username_type == "email" or cookiecutter.username_type == "phone" %}
from typing import ClassVar
{% endif -%}
from django.contrib.auth.models import AbstractUser
from django.db.models import BooleanField
from django.db.models import CharField
{%- if cookiecutter.username_type == "email" or cookiecutter.username_type == "phone" %}
from django.db.models import EmailField
{%- endif %}
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
{%- if cookiecutter.username_type == "email" or cookiecutter.username_type == "phone" %}

from .managers import UserManager
{%- endif %}


class User(AbstractUser):
    """
    Default custom user model for {{cookiecutter.project_name}}.
    If adding fields that need to be filled at user signup,
    check forms.SignupForm and forms.SocialSignupForms accordingly.
    """

    # First and last name do not cover name patterns around the globe
    name = CharField(_("Name of User"), blank=True, max_length=255)
    first_name = None  # type: ignore[assignment]
    last_name = None  # type: ignore[assignment]
{%- if cookiecutter.username_type == "email" %}
    email = EmailField(_("Email Address"), unique=True)
    username = None  # type: ignore[assignment]

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects: ClassVar[UserManager] = UserManager()
{%- elif cookiecutter.username_type == "phone" %}
    username = None  # type: ignore[assignment]
    # Phone is the primary identifier. Stored in E.164 format e.g. +12125552368
    phone = CharField(
        _("Phone Number"),
        max_length=17,
        unique=True,
        help_text=_("Required. Enter in E.164 format: +[country code][number]"),
    )
    phone_verified = BooleanField(_("Phone Verified"), default=False)
    # Email is optional for phone-auth users
    email = EmailField(_("Email Address"), blank=True)

    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = []

    objects: ClassVar[UserManager] = UserManager()

    def save(self, *args, **kwargs):
        """Ensure new phone-auth users start with an unusable password."""
        if self._state.adding and not self.has_usable_password():
            self.set_unusable_password()
        super().save(*args, **kwargs)
{%- endif %}

    def get_absolute_url(self) -> str:
        """Get URL for user's detail view.

        Returns:
            str: URL for user detail.

        """
{%- if cookiecutter.username_type == "email" %}
        return reverse("users:detail", kwargs={"pk": self.pk})
{%- elif cookiecutter.username_type == "phone" %}
        return reverse("users:detail", kwargs={"pk": self.pk})
{%- else %}
        return reverse("users:detail", kwargs={"username": self.username})
{%- endif %}
