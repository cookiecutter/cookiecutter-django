"""
PATCH INSTRUCTIONS for hooks/post_gen_project.py
=================================================

Two changes are needed. Find the lines shown under "--- FIND ---" and
replace or extend them as shown under "+++ REPLACE WITH +++".

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHANGE 1 — managers.py removal
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

--- FIND (somewhere in the post_gen conditional block for username_type):
    if "{{ cookiecutter.username_type }}" == "username":
        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))

+++ REPLACE WITH:
    # managers.py is needed for BOTH "email" and "phone" username types.
    # Only remove it for plain "username" mode.
    if "{{ cookiecutter.username_type }}" == "username":
        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))

(In most versions of cookiecutter-django the managers.py removal already
uses exactly the "username" check, so this change may be a no-op. Verify
that the condition does NOT also remove it when value is "phone".)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHANGE 2 — add phone-specific env variable stubs
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Find the function `set_flags_in_envs()` (or wherever .envs/.local/.django
is written). After the existing flags are set, add:

+++ ADD at the END of the local env block (inside the phone branch):
    if "{{ cookiecutter.username_type }}" == "phone":
        # Stub entries so developers know these vars are expected.
        # Replace with real credentials from your SMS provider.
        local_django_envs = Path(".envs/.local/.django")
        with local_django_envs.open("a") as f:
            f.write(
                "\\n"
                "# ── SMS Provider (phone OTP auth) ─────────────────────\\n"
                "# Uncomment and fill in for your chosen provider.\\n"
                "# Twilio:\\n"
                "# TWILIO_ACCOUNT_SID=\\n"
                "# TWILIO_AUTH_TOKEN=\\n"
                "# TWILIO_PHONE_NUMBER=\\n"
                "# Vonage / Nexmo:\\n"
                "# VONAGE_API_KEY=\\n"
                "# VONAGE_API_SECRET=\\n"
                "# VONAGE_BRAND_NAME={{ cookiecutter.project_slug }}\\n"
                "ACCOUNT_PHONE_VERIFICATION_TIMEOUT=900\\n"
            )

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHANGE 3 — requirements injection (if the hook installs deps via uv)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

If your hook calls `uv add` to install packages, add the phone package:

+++ ADD after the existing uv add calls:
    if "{{ cookiecutter.username_type }}" == "phone":
        subprocess.run(
            [*uv_cmd, "add", "--no-sync", "django-phonenumber-field[phonenumbers]"],
            check=True,
        )
"""
