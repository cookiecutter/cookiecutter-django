"""Post-generation hook for cookiecutter-django.

Handles conditional file removal, secret generation, and uv sync
based on the user's chosen cookiecutter options.
"""

import os
import random
import shutil
import string
import subprocess
import sys
from pathlib import Path

try:
    import colorama

    colorama.init()
except ImportError:
    colorama = None

try:
    from termcolor import colored
except ImportError:

    def colored(text, *args, **kwargs):
        return text


# ---------------------------------------------------------------------------
# Template variable reads
# ---------------------------------------------------------------------------
DEBUG = "{{ cookiecutter.debug }}" == "y"

USERNAME_TYPE = "{{ cookiecutter.username_type }}"
USE_DOCKER = "{{ cookiecutter.use_docker }}".lower()
USE_HEROKU = "{{ cookiecutter.use_heroku }}".lower()
CLOUD_PROVIDER = "{{ cookiecutter.cloud_provider }}"
KEEP_LOCAL_ENVS_IN_VCS = "{{ cookiecutter.keep_local_envs_in_vcs }}".lower()
USE_CELERY = "{{ cookiecutter.use_celery }}".lower()
USE_WHITENOISE = "{{ cookiecutter.use_whitenoise }}".lower()
USE_SENTRY = "{{ cookiecutter.use_sentry }}".lower()
USE_MAILPIT = "{{ cookiecutter.use_mailpit }}".lower()
CI_TOOL = "{{ cookiecutter.ci_tool }}"
FRONTEND_PIPELINE = "{{ cookiecutter.frontend_pipeline }}"
REST_API = "{{ cookiecutter.rest_api }}"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def remove_file(path: Path) -> None:
    if path.exists():
        path.unlink()


def remove_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)


def print_success(message: str) -> None:
    print(colored(message, "green", attrs=["bold"]))  # noqa: T201


def print_info(message: str) -> None:
    print(colored(message, "cyan"))  # noqa: T201


def print_error(message: str) -> None:
    print(colored(message, "red", attrs=["bold"]))  # noqa: T201


def generate_random_string(length: int = 50) -> str:
    chars = string.ascii_lowercase + string.digits + "!@#$%^&*(-_=+)"
    return "".join(random.SystemRandom().choice(chars) for _ in range(length))


# ---------------------------------------------------------------------------
# File removal functions
# ---------------------------------------------------------------------------

def remove_users_managers() -> None:
    """managers.py is only needed for email and phone auth types."""
    remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))


def remove_docker_files() -> None:
    for path in [
        Path("docker-compose.local.yml"),
        Path("docker-compose.production.yml"),
        Path(".dockerignore"),
        Path("compose"),
    ]:
        if path.is_file():
            remove_file(path)
        elif path.is_dir():
            remove_dir(path)


def remove_heroku_files() -> None:
    for path in [Path("Procfile"), Path("runtime.txt")]:
        remove_file(path)


def remove_whitenoise_settings() -> None:
    # Whitenoise is configured in settings; nothing to remove here normally
    pass


def remove_celery_files() -> None:
    remove_file(
        Path("{{ cookiecutter.project_slug }}/celery_app.py")
    )


def remove_mailpit_files() -> None:
    # Mailpit is docker-only; compose files already handled by remove_docker_files
    pass


def remove_sentry_settings() -> None:
    # Sentry is configured inline in settings; nothing to remove
    pass


def remove_frontend_pipeline_files(pipeline: str) -> None:
    keep = pipeline.lower().replace(" ", "_")
    for name in ["gulp", "webpack", "django_compressor"]:
        if name != keep:
            remove_file(Path(f"gulpfile.js") if name == "gulp" else Path(f"webpack.config.js"))


def remove_rest_api_files(rest_api: str) -> None:
    if rest_api == "None":
        # Remove generated DRF/Ninja api files if present
        remove_dir(Path("{{ cookiecutter.project_slug }}/api"))


def remove_ci_files(ci_tool: str) -> None:
    all_ci = {
        "Travis": [".travis.yml"],
        "Gitlab": [".gitlab-ci.yml"],
        "Github": [".github/workflows/ci.yml"],
        "Drone": [".drone.yml"],
    }
    for tool, files in all_ci.items():
        if tool != ci_tool:
            for f in files:
                remove_file(Path(f))


# ---------------------------------------------------------------------------
# Username type: phone-specific file handling
# ---------------------------------------------------------------------------

def append_phone_env_vars() -> None:
    """
    Append phone/SMS placeholder env vars to the local Django env file.
    Called only when USERNAME_TYPE == 'phone'.
    """
    local_env = Path(".envs/.local/.django")
    if local_env.exists():
        addition = """
# Phone / OTP verification
# ─────────────────────────────────────────────────────────
ACCOUNT_PHONE_VERIFICATION_TIMEOUT=900

# SMS provider — uncomment ONE block and fill in your credentials.
# During local development the OTP is logged to the console.

# Twilio
# TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# TWILIO_AUTH_TOKEN=your_auth_token_here
# TWILIO_PHONE_NUMBER=+15005550006

# Vonage / Nexmo
# VONAGE_API_KEY=your_api_key
# VONAGE_API_SECRET=your_api_secret
# VONAGE_BRAND_NAME={{ cookiecutter.project_name }}
"""
        with open(local_env, "a") as f:
            f.write(addition)


# ---------------------------------------------------------------------------
# Secret key injection
# ---------------------------------------------------------------------------

def set_flag(file_path: Path, flag: str, value: str | None = None) -> None:
    if not file_path.exists():
        return
    if value is None:
        value = generate_random_string()
    with open(file_path) as f:
        content = f.read()
    content = content.replace(flag, value, 1)
    with open(file_path, "w") as f:
        f.write(content)


def set_django_secret_key(file_path: Path) -> None:
    set_flag(file_path, "!!!SET DJANGO_SECRET_KEY!!!")


def set_postgres_password(file_path: Path) -> None:
    set_flag(file_path, "!!!SET POSTGRES_PASSWORD!!!")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    # --- Username type ---
    if USERNAME_TYPE == "username":
        # email-based managers.py is not needed for plain username mode
        remove_users_managers()

    if USERNAME_TYPE == "phone":
        if KEEP_LOCAL_ENVS_IN_VCS == "y":
            append_phone_env_vars()

    # --- Docker ---
    if USE_DOCKER == "n" and USE_HEROKU == "n":
        if KEEP_LOCAL_ENVS_IN_VCS == "y":
            # generate secrets in local env files
            set_django_secret_key(Path(".envs/.local/.django"))
        remove_docker_files()

    if USE_DOCKER == "y":
        set_django_secret_key(Path(".envs/.local/.django"))
        set_postgres_password(Path(".envs/.local/.postgres"))

    if USE_DOCKER == "y" and CLOUD_PROVIDER != "AWS":
        # Remove AWS-specific compose overrides if any
        pass

    # --- Heroku ---
    if USE_HEROKU == "n":
        remove_heroku_files()

    if USE_HEROKU == "y" and KEEP_LOCAL_ENVS_IN_VCS == "y":
        if USE_DOCKER == "n":
            set_django_secret_key(Path(".envs/.local/.django"))

    # --- Celery ---
    if USE_CELERY == "n":
        remove_celery_files()

    # --- CI ---
    remove_ci_files(CI_TOOL)

    # --- REST API ---
    remove_rest_api_files(REST_API)

    # --- env VCS guard ---
    if KEEP_LOCAL_ENVS_IN_VCS == "n":
        # Make sure local envs are gitignored (already in .gitignore template)
        pass

    # --- Cloud: no docker + no cloud = remove cloud-specific requirements ---
    if CLOUD_PROVIDER == "None" and USE_DOCKER == "n":
        # nothing to remove for base cloud provider
        pass

    if not DEBUG:
        print_success(  # noqa: T201
            "\n"
            " [SUCCESS] Project {{ cookiecutter.project_name }} "
            "has been created!"
        )
        if USERNAME_TYPE == "phone":
            print_info(  # noqa: T201
                "\n"
                " ── Phone OTP Auth ──────────────────────────────────────────\n"
                " Your project uses phone number + OTP authentication.\n"
                " Next steps:\n"
                "   1. Open users/adapters.py → send_verification_code_sms()\n"
                "   2. Uncomment your SMS provider block (Twilio / Vonage / SNS)\n"
                "   3. Add your provider credentials to .envs/.local/.django\n"
                " During development, OTP codes are printed to the Django log.\n"
                " ────────────────────────────────────────────────────────────\n"
            )


if __name__ == "__main__":
    main()
