"""Pre-generation hook — validates cookiecutter variable combinations."""

import re
import sys

# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

MODULE_REGEX = r"^[_a-zA-Z][_a-zA-Z0-9]+$"
project_slug = "{{ cookiecutter.project_slug }}"

if not re.match(MODULE_REGEX, project_slug):
    print(  # noqa: T201
        f"ERROR: '{project_slug}' is not a valid Python module name. "
        "Use only letters, digits and underscores, and start with a letter."
    )
    sys.exit(1)

# ---------------------------------------------------------------------------
# Phone auth constraints
# ---------------------------------------------------------------------------

USERNAME_TYPE = "{{ cookiecutter.username_type }}"
USE_HEROKU = "{{ cookiecutter.use_heroku }}"

if USERNAME_TYPE == "phone" and USE_HEROKU == "y":
    # Phone auth works fine on Heroku, but the user should know they
    # must configure an SMS provider add-on (e.g. Twilio).
    print(  # noqa: T201
        "WARNING: You selected phone auth + Heroku. "
        "Remember to provision an SMS provider add-on (e.g. Twilio) on Heroku "
        "and set the corresponding environment variables."
    )
    # Not a hard error — continue generation.
