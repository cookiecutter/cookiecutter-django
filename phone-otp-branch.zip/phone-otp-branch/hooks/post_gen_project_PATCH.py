"""
PATCH for hooks/post_gen_project.py
====================================
This file shows the TWO changes needed in the existing hook.

CHANGE 1 — update the `remove_manager` condition
-------------------------------------------------
Find this existing block (around line 457-470 in the original):

    if "{{ cookiecutter.username_type }}" != "email":
        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))

Replace with:

    if "{{ cookiecutter.username_type }}" not in ("email", "phone"):
        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))


CHANGE 2 — remove phone-specific files when NOT using phone auth
----------------------------------------------------------------
Add the block below AFTER the existing username_type/managers block:

    if "{{ cookiecutter.username_type }}" != "phone":
        # Remove phone-specific allauth templates (they only apply to phone auth)
        import shutil
        phone_templates = Path(
            "{{ cookiecutter.project_slug }}/templates/account/phone"
        )
        if phone_templates.exists():
            shutil.rmtree(phone_templates)


That's it — two surgical changes, nothing else in the hook needs to touch
the new phone option because:
- models.py, managers.py, forms.py, adapters.py, admin.py, views.py all use
  Jinja2 conditionals inside the template files themselves.
- The allauth settings block is already conditional in base.py template.
- The migration 0001_initial.py is gated by {%- if cookiecutter.username_type == "phone" %}
  at the top of that file, so it renders to an empty file for other types;
  the hook's existing empty-file cleanup will remove it automatically.
"""

# ─────────────────────────────────────────────────────────────────────────────
# Full unified diff to apply:
# ─────────────────────────────────────────────────────────────────────────────

DIFF = """
--- a/hooks/post_gen_project.py
+++ b/hooks/post_gen_project.py
@@ find:
-    if "{{ cookiecutter.username_type }}" != "email":
-        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))
+    if "{{ cookiecutter.username_type }}" not in ("email", "phone"):
+        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))
+
+    if "{{ cookiecutter.username_type }}" != "phone":
+        import shutil
+        phone_templates = Path(
+            "{{ cookiecutter.project_slug }}/templates/account/phone"
+        )
+        if phone_templates.exists():
+            shutil.rmtree(phone_templates)
"""
