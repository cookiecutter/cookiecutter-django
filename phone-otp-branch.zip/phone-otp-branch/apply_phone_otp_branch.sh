#!/usr/bin/env bash
# =============================================================================
# apply_phone_otp_branch.sh
#
# Run this from the ROOT of your Ali-Fani/cookiecutter-django clone to
# create the feature/phone-otp-auth branch and copy all generated files
# into the right places.
#
# Usage:
#   git clone https://github.com/Ali-Fani/cookiecutter-django.git
#   cd cookiecutter-django
#   bash /path/to/apply_phone_otp_branch.sh
# =============================================================================
set -euo pipefail

TEMPLATE_DIR='{{cookiecutter.project_slug}}'

echo "==> Creating branch feature/phone-otp-auth"
git checkout -b feature/phone-otp-auth

# ---------------------------------------------------------------------------
# 1. cookiecutter.json — add "phone" as third username_type option
# ---------------------------------------------------------------------------
echo "==> Patching cookiecutter.json"
python3 - <<'PYEOF'
import json, pathlib

p = pathlib.Path("cookiecutter.json")
data = json.loads(p.read_text())
if "phone" not in data["username_type"]:
    data["username_type"].append("phone")
p.write_text(json.dumps(data, indent=2) + "\n")
print("  username_type is now:", data["username_type"])
PYEOF

# ---------------------------------------------------------------------------
# 2. users/models.py  — add phone branch
# ---------------------------------------------------------------------------
echo "==> Writing ${TEMPLATE_DIR}/users/models.py"
cat > "${TEMPLATE_DIR}/users/models.py" << 'JINJA'
{%- if cookiecutter.username_type == "email" or cookiecutter.username_type == "phone" %}
from typing import ClassVar
{% endif -%}
from django.contrib.auth.models import AbstractUser
from django.db.models import BooleanField
from django.db.models import CharField
{%- if cookiecutter.username_type == "email" or cookiecutter.username_type == "phone" %}
from django.db.models import EmailField
{%- endif %}
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
{%- if cookiecutter.username_type == "email" or cookiecutter.username_type == "phone" %}

from .managers import UserManager
{%- endif %}


class User(AbstractUser):
    """
    Default custom user model for {{cookiecutter.project_name}}.
    If adding fields that need to be filled at user signup,
    check forms.SignupForm and forms.SocialSignupForms accordingly.
    """

    name = CharField(_("Name of User"), blank=True, max_length=255)
    first_name = None  # type: ignore[assignment]
    last_name = None  # type: ignore[assignment]
{%- if cookiecutter.username_type == "email" %}
    email = EmailField(_("Email Address"), unique=True)
    username = None  # type: ignore[assignment]

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects: ClassVar[UserManager] = UserManager()
{%- elif cookiecutter.username_type == "phone" %}
    username = None  # type: ignore[assignment]
    phone = CharField(
        _("Phone Number"),
        max_length=17,
        unique=True,
        help_text=_("Required. Enter in E.164 format: +[country code][number]"),
    )
    phone_verified = BooleanField(_("Phone Verified"), default=False)
    email = EmailField(_("Email Address"), blank=True)

    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = []

    objects: ClassVar[UserManager] = UserManager()

    def save(self, *args, **kwargs):
        if self._state.adding and not self.has_usable_password():
            self.set_unusable_password()
        super().save(*args, **kwargs)
{%- endif %}

    def get_absolute_url(self) -> str:
{%- if cookiecutter.username_type == "email" or cookiecutter.username_type == "phone" %}
        return reverse("users:detail", kwargs={"pk": self.pk})
{%- else %}
        return reverse("users:detail", kwargs={"username": self.username})
{%- endif %}
JINJA

# ---------------------------------------------------------------------------
# 3. users/managers.py  — add phone branch
# ---------------------------------------------------------------------------
echo "==> Writing ${TEMPLATE_DIR}/users/managers.py"
cat > "${TEMPLATE_DIR}/users/managers.py" << 'JINJA'
{%- if cookiecutter.username_type == "email" %}
from django.contrib.auth.base_user import BaseUserManager
from django.utils.translation import gettext_lazy as _


class UserManager(BaseUserManager):
    """Custom manager where email is the unique identifier."""

    def create_user(self, email: str, password: str | None = None, **extra_fields):
        if not email:
            raise ValueError(_("The Email must be set"))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email: str, password: str | None = None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        if extra_fields.get("is_staff") is not True:
            raise ValueError(_("Superuser must have is_staff=True."))
        if extra_fields.get("is_superuser") is not True:
            raise ValueError(_("Superuser must have is_superuser=True."))
        return self.create_user(email, password, **extra_fields)
{%- elif cookiecutter.username_type == "phone" %}
from django.contrib.auth.base_user import BaseUserManager
from django.utils.translation import gettext_lazy as _


class UserManager(BaseUserManager):
    """
    Custom manager where phone number is the unique identifier.
    Phone numbers must be in E.164 format: +[country code][number]
    """

    def create_user(self, phone: str, password: str | None = None, **extra_fields):
        if not phone:
            raise ValueError(_("The Phone Number must be set"))
        user = self.model(phone=phone, **extra_fields)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save()
        return user

    def create_superuser(self, phone: str, password: str | None = None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        if extra_fields.get("is_staff") is not True:
            raise ValueError(_("Superuser must have is_staff=True."))
        if extra_fields.get("is_superuser") is not True:
            raise ValueError(_("Superuser must have is_superuser=True."))
        return self.create_user(phone, password, **extra_fields)
{%- endif %}
JINJA

# ---------------------------------------------------------------------------
# 4. users/adapters.py  — phone adapter methods
# ---------------------------------------------------------------------------
echo "==> Writing ${TEMPLATE_DIR}/users/adapters.py"
cat > "${TEMPLATE_DIR}/users/adapters.py" << 'JINJA'
"""django-allauth adapter for {{ cookiecutter.project_name }}."""
{%- if cookiecutter.username_type == "phone" %}

import logging

from django.contrib.auth import get_user_model
from django.http import HttpRequest

from allauth.account.adapter import DefaultAccountAdapter
from allauth.socialaccount.adapter import DefaultSocialAccountAdapter

logger = logging.getLogger(__name__)


class AccountAdapter(DefaultAccountAdapter):
    def is_open_for_signup(self, request: HttpRequest) -> bool:
        return getattr(self.request, "allow_signup", True)

    # ── phone storage ──────────────────────────────────────────────────────

    def get_phone(self, user) -> tuple[str, bool] | None:
        phone = getattr(user, "phone", None)
        if phone:
            return phone, user.phone_verified
        return None

    def set_phone(self, user, phone: str, verified: bool) -> None:
        user.phone = phone
        user.phone_verified = verified
        user.save(update_fields=["phone", "phone_verified"])

    def set_phone_verified(self, user, phone: str) -> None:
        user.phone_verified = True
        user.save(update_fields=["phone_verified"])

    def get_user_by_phone(self, phone: str):
        User = get_user_model()
        try:
            return User.objects.get(phone=phone)
        except User.DoesNotExist:
            return None

    # ── SMS sending ────────────────────────────────────────────────────────

    def send_verification_code_sms(self, user, phone: str, code: str, **kwargs) -> None:
        """
        Send OTP via your chosen SMS provider. Replace the body below.

        Twilio example:
            from django.conf import settings
            from twilio.rest import Client
            Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN).messages.create(
                body=f"Your {{ cookiecutter.project_name }} code: {code}",
                from_=settings.TWILIO_PHONE_NUMBER,
                to=phone,
            )

        Vonage example:
            import vonage
            from django.conf import settings
            vonage.Sms(vonage.Client(key=settings.VONAGE_API_KEY,
                                     secret=settings.VONAGE_API_SECRET)).send_message(
                {"from": settings.VONAGE_BRAND_NAME,
                 "to": phone.lstrip("+"),
                 "text": f"Your {{ cookiecutter.project_name }} code: {code}"})
        """
        # TODO: implement with your real SMS provider
        logger.warning("OTP for %s: %s  (implement send_verification_code_sms!)", phone, code)

    def send_unknown_account_sms(self, phone: str, **kwargs) -> None:
        logger.warning("Unknown account SMS requested for %s (not implemented)", phone)


class SocialAccountAdapter(DefaultSocialAccountAdapter):
    def is_open_for_signup(self, request: HttpRequest, sociallogin) -> bool:
        return getattr(self.request, "allow_signup", True)
{%- else %}

from django.http import HttpRequest

from allauth.account.adapter import DefaultAccountAdapter
from allauth.socialaccount.adapter import DefaultSocialAccountAdapter


class AccountAdapter(DefaultAccountAdapter):
    def is_open_for_signup(self, request: HttpRequest) -> bool:
        return getattr(self.request, "allow_signup", True)


class SocialAccountAdapter(DefaultSocialAccountAdapter):
    def is_open_for_signup(self, request: HttpRequest, sociallogin) -> bool:
        return getattr(self.request, "allow_signup", True)
{%- endif %}
JINJA

# ---------------------------------------------------------------------------
# 5. users/tests/factories.py — phone factory
# ---------------------------------------------------------------------------
echo "==> Writing ${TEMPLATE_DIR}/users/tests/factories.py"
cat > "${TEMPLATE_DIR}/users/tests/factories.py" << 'JINJA'
from collections.abc import Sequence
from typing import Any

import factory
from django.contrib.auth import get_user_model
from factory import post_generation
from factory.django import DjangoModelFactory

{%- if cookiecutter.username_type == "phone" %}


class UserFactory(DjangoModelFactory):
    phone = factory.Sequence(lambda n: f"+1212555{n:04d}")
    phone_verified = False
    email = factory.LazyAttribute(lambda obj: f"user{obj.phone[-4:]}@example.com")
    name = factory.Faker("name")
    is_active = True

    @post_generation
    def password(self, create: bool, extracted: Sequence[Any], **kwargs):
        if extracted:
            self.set_password(extracted)
        else:
            self.set_unusable_password()
        if create:
            self.save()

    @classmethod
    def _after_postgeneration(cls, instance, create, results=None):
        if create and results:
            instance.save()

    class Meta:
        model = get_user_model()
        django_get_or_create = ["phone"]
{%- elif cookiecutter.username_type == "email" %}


class UserFactory(DjangoModelFactory):
    email = factory.Faker("email")
    name = factory.Faker("name")
    is_active = True

    @post_generation
    def password(self, create: bool, extracted: Sequence[Any], **kwargs):
        password = (
            extracted
            if extracted
            else factory.Faker("password", length=42, special_chars=True,
                               digits=True, upper_case=True, lower_case=True,
                               ).evaluate(None, None, extra={"locale": None})
        )
        self.set_password(password)
        if create:
            self.save()

    @classmethod
    def _after_postgeneration(cls, instance, create, results=None):
        if create and results:
            instance.save()

    class Meta:
        model = get_user_model()
        django_get_or_create = ["email"]
{%- else %}


class UserFactory(DjangoModelFactory):
    username = factory.Faker("user_name")
    email = factory.Faker("email")
    name = factory.Faker("name")
    is_active = True

    @post_generation
    def password(self, create: bool, extracted: Sequence[Any], **kwargs):
        password = (
            extracted
            if extracted
            else factory.Faker("password", length=42, special_chars=True,
                               digits=True, upper_case=True, lower_case=True,
                               ).evaluate(None, None, extra={"locale": None})
        )
        self.set_password(password)
        if create:
            self.save()

    @classmethod
    def _after_postgeneration(cls, instance, create, results=None):
        if create and results:
            instance.save()

    class Meta:
        model = get_user_model()
        django_get_or_create = ["username"]
{%- endif %}
JINJA

# ---------------------------------------------------------------------------
# 6. users/tests/test_models.py — phone model tests
# ---------------------------------------------------------------------------
echo "==> Patching ${TEMPLATE_DIR}/users/tests/test_models.py"
# Append phone-specific tests to existing file rather than overwriting
cat >> "${TEMPLATE_DIR}/users/tests/test_models.py" << 'JINJA'
{%- if cookiecutter.username_type == "phone" %}


class TestPhoneUserModel:
    """Additional tests specific to phone-auth users."""

    def test_new_user_has_unusable_password(self):
        from {{ cookiecutter.project_slug }}.users.tests.factories import UserFactory
        user = UserFactory()
        assert not user.has_usable_password()

    def test_user_with_explicit_password_is_usable(self):
        from {{ cookiecutter.project_slug }}.users.tests.factories import UserFactory
        user = UserFactory(password="SuperSecretPass123!")  # noqa: S106
        assert user.has_usable_password()

    def test_phone_is_username_field(self):
        from django.contrib.auth import get_user_model
        assert get_user_model().USERNAME_FIELD == "phone"

    def test_superuser_has_usable_password(self, db):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        user = User.objects.create_superuser(phone="+12125559999", password="AdminPass!")  # noqa: S106
        assert user.has_usable_password()
        assert user.is_superuser
{%- endif %}
JINJA

# ---------------------------------------------------------------------------
# 7. HTML templates — phone OTP screens
# ---------------------------------------------------------------------------
echo "==> Creating phone OTP templates"
TPLDIR="${TEMPLATE_DIR}/templates/account/phone"
mkdir -p "$TPLDIR"

cat > "${TPLDIR}/verification_code.html" << 'HTML'
{% extends "account/base_entrance.html" %}
{% load i18n %}

{% block head_title %}{% trans "Verify Your Phone" %}{% endblock head_title %}

{% block inner %}
  <h1 class="mb-3">{% trans "Phone Verification" %}</h1>
  <p class="text-muted mb-4">
    {% blocktrans trimmed with phone=phone %}
      We sent a verification code to <strong>{{ phone }}</strong>.
      Enter it below to continue.
    {% endblocktrans %}
  </p>
  <form method="post" action="{{ action_url }}">
    {% csrf_token %}
    {{ form.as_p }}
    {% if redirect_field_value %}
      <input type="hidden" name="{{ redirect_field_name }}" value="{{ redirect_field_value }}" />
    {% endif %}
    <button type="submit" class="btn btn-primary w-100 mb-3">{% trans "Verify" %}</button>
  </form>
  {% if can_resend %}
    <div class="text-center">
      <form method="post" action="{{ resend_url }}">
        {% csrf_token %}
        <button type="submit" class="btn btn-link btn-sm text-muted">
          {% trans "Resend verification code" %}
        </button>
      </form>
    </div>
  {% endif %}
{% endblock inner %}
HTML

# ---------------------------------------------------------------------------
# 8. settings/base.py — patch the django-allauth section
# ---------------------------------------------------------------------------
echo ""
echo "==> MANUAL STEP REQUIRED: patch config/settings/base.py"
echo "    Find the '# django-allauth' comment block and replace the"
echo "    ACCOUNT_* settings with the following conditional block:"
echo ""
cat << 'SETTINGS_PATCH'
# django-allauth
# ------------------------------------------------------------------------------
ACCOUNT_ALLOW_REGISTRATION = env.bool("DJANGO_ACCOUNT_ALLOW_REGISTRATION", default=True)
{%- if cookiecutter.username_type == "username" %}
ACCOUNT_LOGIN_METHODS = {"username"}
ACCOUNT_SIGNUP_FIELDS = ["username*", "email*", "password1*", "password2*"]
{%- elif cookiecutter.username_type == "email" %}
ACCOUNT_LOGIN_METHODS = {"email"}
ACCOUNT_SIGNUP_FIELDS = ["email*", "password1*", "password2*"]
{%- elif cookiecutter.username_type == "phone" %}
ACCOUNT_LOGIN_METHODS = {"phone"}
ACCOUNT_SIGNUP_FIELDS = ["phone*"]
ACCOUNT_PHONE_VERIFICATION_ENABLED = True
ACCOUNT_PHONE_VERIFICATION_SUPPORTS_RESEND = True
ACCOUNT_PHONE_VERIFICATION_TIMEOUT = env.int("ACCOUNT_PHONE_VERIFICATION_TIMEOUT", default=900)
{%- endif %}
ACCOUNT_ADAPTER = "{{ cookiecutter.project_slug }}.users.adapters.AccountAdapter"
ACCOUNT_FORMS = {"signup": "{{ cookiecutter.project_slug }}.users.forms.UserSignupForm"}
SOCIALACCOUNT_ADAPTER = "{{ cookiecutter.project_slug }}.users.adapters.SocialAccountAdapter"
SOCIALACCOUNT_FORMS = {"signup": "{{ cookiecutter.project_slug }}.users.forms.UserSocialSignupForm"}
{%- if cookiecutter.username_type == "phone" %}
# SMS provider env vars — fill in .envs/.local/.django
# TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN / TWILIO_PHONE_NUMBER
# VONAGE_API_KEY / VONAGE_API_SECRET / VONAGE_BRAND_NAME
{%- endif %}
SETTINGS_PATCH

# ---------------------------------------------------------------------------
# 9. requirements/base.txt — phone dependency
# ---------------------------------------------------------------------------
echo ""
echo "==> MANUAL STEP REQUIRED: add to requirements/base.txt inside"
echo "    a Jinja block:"
echo ""
cat << 'REQ_PATCH'
{%- if cookiecutter.username_type == "phone" %}
django-phonenumber-field[phonenumbers]>=7.3.0
# Uncomment your SMS provider:
# twilio>=9.0.0
# vonage>=3.0.0
{%- endif %}
REQ_PATCH

# ---------------------------------------------------------------------------
# 10. Stage and commit
# ---------------------------------------------------------------------------
echo ""
echo "==> Staging all changes"
git add \
  cookiecutter.json \
  "${TEMPLATE_DIR}/users/models.py" \
  "${TEMPLATE_DIR}/users/managers.py" \
  "${TEMPLATE_DIR}/users/adapters.py" \
  "${TEMPLATE_DIR}/users/tests/factories.py" \
  "${TEMPLATE_DIR}/users/tests/test_models.py" \
  "${TEMPLATE_DIR}/templates/account/phone/verification_code.html"

echo ""
echo "==> All automated changes staged."
echo ""
echo "Next steps:"
echo "  1. Manually patch config/settings/base.py (see output above)"
echo "  2. Manually patch requirements/base.txt (see output above)"
echo "  3. Manually patch hooks/post_gen_project.py (see hooks_patch_instructions.py)"
echo "  4. Manually patch hooks/pre_gen_project.py (see pre_gen_patch_instructions.py)"
echo "  5. Run: git add -p && git commit -m 'feat: add phone+OTP as username_type option'"
echo "  6. git push origin feature/phone-otp-auth"
echo "  7. Open PR against Ali-Fani/cookiecutter-django master"
