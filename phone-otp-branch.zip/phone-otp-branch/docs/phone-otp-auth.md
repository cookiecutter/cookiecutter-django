# Phone Number + OTP Authentication

When you select `username_type = phone` during project generation, your project
is configured to authenticate users via their phone number and a one-time password
(OTP) sent by SMS. Password-based login is supported but **optional** — new users
are created with an unusable password by default.

## How it works

1. User enters their phone number (E.164 format, e.g. `+12125552368`) on the
   signup or login page.
2. allauth generates a time-limited OTP code and calls your adapter's
   `send_verification_code_sms()`.
3. User enters the OTP on the verification screen.
4. On success, allauth logs the user in (signup: also creates the account).

The entire OTP lifecycle — generation, expiry, max attempts, resend — is handled
by `django-allauth`. You only need to wire up the SMS delivery.

## User model

| Field | Type | Notes |
|---|---|---|
| `phone` | `CharField(unique=True)` | `USERNAME_FIELD`. E.164 format. |
| `phone_verified` | `BooleanField` | Set to `True` after first OTP verification |
| `email` | `EmailField(blank=True)` | Optional. Users can add later. |
| `name` | `CharField(blank=True)` | Display name |
| `password` | (inherited) | Unusable by default; users can optionally set one |

## Wiring up an SMS provider

Open `{{ project_slug }}/users/adapters.py` and implement
`AccountAdapter.send_verification_code_sms()`. Provider examples are in the
docstring of that method.

### Twilio

```python
# requirements/base.txt: add twilio>=9.0.0

from django.conf import settings
from twilio.rest import Client

def send_verification_code_sms(self, user, phone, code, **kwargs):
    client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    client.messages.create(
        body=f"Your verification code is: {code}",
        from_=settings.TWILIO_PHONE_NUMBER,
        to=phone,
    )
```

Add to `.envs/.local/.django`:

```ini
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+15005550006
```

### Vonage (Nexmo)

```python
# requirements/base.txt: add vonage>=3.0.0

import vonage
from django.conf import settings

def send_verification_code_sms(self, user, phone, code, **kwargs):
    client = vonage.Client(key=settings.VONAGE_API_KEY, secret=settings.VONAGE_API_SECRET)
    vonage.Sms(client).send_message({
        "from": settings.VONAGE_BRAND_NAME,
        "to": phone.lstrip("+"),
        "text": f"Your verification code is: {code}",
    })
```

### AWS SNS

```python
# No extra package needed if cloud_provider=AWS (boto3 is already installed)

import boto3
from django.conf import settings

def send_verification_code_sms(self, user, phone, code, **kwargs):
    sns = boto3.client("sns", region_name=settings.AWS_SNS_REGION_NAME)
    sns.publish(
        PhoneNumber=phone,
        Message=f"Your verification code is: {code}",
    )
```

## Development without an SMS provider

During development, the default adapter logs the OTP code to the console
via `logger.warning(...)`. You can see it in the Django dev server output:

```
WARNING users.adapters send_verification_code_sms() is not implemented.
OTP code for +12125552368: 482917
```

## Optional password login

A user can optionally set a password after signing up (e.g. via a
"Change password" form). Once set, they can log in with either
phone+OTP **or** phone+password.

This is controlled by allauth's `ACCOUNT_LOGIN_METHODS`. To allow both
simultaneously, update your settings:

```python
# config/settings/base.py
ACCOUNT_LOGIN_METHODS = {"phone"}  # OTP only (default generated config)

# --- OR ---

ACCOUNT_LOGIN_METHODS = {"phone", "email"}  # if you also want email login
```

## Superuser creation

The management command for creating a superuser requires a phone number and a
real password (needed for Django admin access):

```bash
python manage.py createsuperuser
# Phone Number: +12125559999
# Password: (your password)
```

## allauth settings reference

| Setting | Default | Description |
|---|---|---|
| `ACCOUNT_PHONE_VERIFICATION_ENABLED` | `True` | Require OTP verification |
| `ACCOUNT_PHONE_VERIFICATION_TIMEOUT` | `900` | OTP expiry in seconds |
| `ACCOUNT_PHONE_VERIFICATION_MAX_ATTEMPTS` | `3` | Wrong attempts before lockout |
| `ACCOUNT_PHONE_VERIFICATION_SUPPORTS_RESEND` | `True` | Allow resending OTP |
