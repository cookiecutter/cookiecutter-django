"""
Additions to tests/test_cookiecutter_generation.py for phone auth.

Add these fixtures/tests to the existing test file.
"""
import pytest


# ---------------------------------------------------------------------------
# Add "phone" to the username_type parametrize list wherever it appears.
# e.g. change:
#   @pytest.mark.parametrize("username_type", ["username", "email"])
# to:
#   @pytest.mark.parametrize("username_type", ["username", "email", "phone"])
# ---------------------------------------------------------------------------


# ── New standalone tests for phone auth ─────────────────────────────────────

@pytest.fixture
def phone_context(context):
    """Cookiecutter context override for phone auth."""
    return {**context, "username_type": "phone"}


def test_phone_model_has_phone_field(cookies, phone_context):
    result = cookies.bake(extra_context=phone_context)
    assert result.exit_code == 0
    assert result.exception is None

    model_file = result.project_path / result.context["project_slug"] / "users" / "models.py"
    content = model_file.read_text()

    assert "phone = " in content
    assert "phone_verified = " in content
    assert 'USERNAME_FIELD = "phone"' in content
    assert "username = None" in content


def test_phone_model_has_no_username_field(cookies, phone_context):
    result = cookies.bake(extra_context=phone_context)
    assert result.exit_code == 0

    model_file = result.project_path / result.context["project_slug"] / "users" / "models.py"
    content = model_file.read_text()

    # username should be nulled out
    assert "username = None" in content
    # should NOT declare a new username field
    assert "username = CharField" not in content


def test_phone_manager_exists(cookies, phone_context):
    result = cookies.bake(extra_context=phone_context)
    assert result.exit_code == 0

    managers_file = result.project_path / result.context["project_slug"] / "users" / "managers.py"
    assert managers_file.exists()
    content = managers_file.read_text()
    assert "create_user" in content
    assert "set_unusable_password" in content


def test_phone_adapter_exists(cookies, phone_context):
    result = cookies.bake(extra_context=phone_context)
    assert result.exit_code == 0

    adapters_file = result.project_path / result.context["project_slug"] / "users" / "adapters.py"
    assert adapters_file.exists()
    content = adapters_file.read_text()

    assert "get_phone" in content
    assert "set_phone" in content
    assert "get_user_by_phone" in content
    assert "send_verification_code_sms" in content


def test_phone_settings_use_correct_login_methods(cookies, phone_context):
    result = cookies.bake(extra_context=phone_context)
    assert result.exit_code == 0

    settings_file = (
        result.project_path
        / result.context["project_slug"]
        / "config"
        / "settings"
        / "base.py"
    )
    content = settings_file.read_text()

    assert 'ACCOUNT_LOGIN_METHODS = {"phone"}' in content
    assert "ACCOUNT_SIGNUP_FIELDS" in content
    assert "phone*" in content
    assert "ACCOUNT_PHONE_VERIFICATION_ENABLED" in content


def test_phone_otp_templates_exist(cookies, phone_context):
    result = cookies.bake(extra_context=phone_context)
    assert result.exit_code == 0

    templates_dir = result.project_path / result.context["project_slug"] / "templates" / "account"
    otp_template = templates_dir / "phone" / "verification_code.html"
    assert otp_template.exists(), "OTP verification code template must exist for phone auth"


def test_username_type_username_no_managers(cookies, context):
    """username mode should NOT generate managers.py."""
    ctx = {**context, "username_type": "username"}
    result = cookies.bake(extra_context=ctx)
    assert result.exit_code == 0

    managers_file = result.project_path / result.context["project_slug"] / "users" / "managers.py"
    assert not managers_file.exists()


def test_phone_admin_shows_phone_field(cookies, phone_context):
    result = cookies.bake(extra_context=phone_context)
    assert result.exit_code == 0

    admin_file = result.project_path / result.context["project_slug"] / "users" / "admin.py"
    content = admin_file.read_text()
    assert '"phone"' in content
    assert '"phone_verified"' in content
