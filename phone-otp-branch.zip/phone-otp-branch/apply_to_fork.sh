#!/usr/bin/env bash
# =============================================================================
# apply_to_fork.sh
#
# Run this from the ROOT of your Ali-Fani/cookiecutter-django clone to apply
# the phone OTP auth feature branch.
#
# Usage:
#   git clone https://github.com/Ali-Fani/cookiecutter-django.git
#   cd cookiecutter-django
#   bash /path/to/apply_to_fork.sh
# =============================================================================
set -euo pipefail

BRANCH="feature/phone-otp-auth"
SLUG='{{cookiecutter.project_slug}}'
USERS="${SLUG}/users"
SETTINGS="${SLUG}/config/settings"
TEMPLATES="${SLUG}/templates/account"

echo "→ Creating branch $BRANCH"
git checkout -b "$BRANCH"

# ---------------------------------------------------------------------------
# 1. cookiecutter.json — add "phone" to username_type choices
# ---------------------------------------------------------------------------
echo "→ Patching cookiecutter.json"
python3 - << 'PYEOF'
import json, pathlib
p = pathlib.Path("cookiecutter.json")
data = json.loads(p.read_text())
ut = data["username_type"]
if "phone" not in ut:
    ut.append("phone")
    data["username_type"] = ut
    p.write_text(json.dumps(data, indent=2) + "\n")
    print("  ✓ added 'phone' to username_type")
else:
    print("  already present, skipping")
PYEOF

# ---------------------------------------------------------------------------
# 2. users/models.py — add phone branch
# ---------------------------------------------------------------------------
echo "→ Patching ${USERS}/models.py"
python3 - << 'PYEOF'
import pathlib, re
p = pathlib.Path("{{cookiecutter.project_slug}}/users/models.py")
src = p.read_text()

# Guard: only patch if the phone branch isn't there yet
if 'username_type == "phone"' in src:
    print("  already patched, skipping")
else:
    # Inject phone branch right after the email branch closing {%- endif %}
    # that handles username = None / email = EmailField block
    phone_branch = '''
{%- elif cookiecutter.username_type == "phone" %}
    username = None  # type: ignore[assignment]
    phone = CharField(
        _("Phone Number"),
        max_length=17,
        unique=True,
        help_text=_("Required. Enter in E.164 format: +[country code][number]"),
    )
    phone_verified = BooleanField(_("Phone Verified"), default=False)
    email = EmailField(_("Email Address"), blank=True)

    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = []

    objects: ClassVar[UserManager] = UserManager()

    def save(self, *args, **kwargs):
        if self._state.adding and not self.has_usable_password():
            self.set_unusable_password()
        super().save(*args, **kwargs)'''

    # Find the spot: after "USERNAME_FIELD = "email"" email block, before {%- endif %}
    # We insert before the final {%- endif %} that closes the email branch
    src = re.sub(
        r'(    USERNAME_FIELD = "email"\s+REQUIRED_FIELDS = \[\]\s+objects: ClassVar\[UserManager\] = UserManager\(\)\s*)',
        lambda m: m.group(0) + phone_branch + "\n",
        src,
        count=1,
    )

    # Add BooleanField to imports if not present
    if "BooleanField" not in src:
        src = src.replace(
            "from django.db.models import CharField",
            "from django.db.models import BooleanField\nfrom django.db.models import CharField",
        )

    # Add ClassVar import for phone branch too
    if "ClassVar" not in src:
        src = src.replace(
            "{%- if cookiecutter.username_type == \"email\" %}\nfrom typing import ClassVar",
            '{%- if cookiecutter.username_type in ("email", "phone") %}\nfrom typing import ClassVar',
        )
    else:
        src = src.replace(
            '{%- if cookiecutter.username_type == "email" %}\nfrom typing import ClassVar',
            '{%- if cookiecutter.username_type in ("email", "phone") %}\nfrom typing import ClassVar',
        )

    # Fix UserManager import condition to include phone
    src = src.replace(
        'from .managers import UserManager\n{%- endif %}',
        'from .managers import UserManager\n{%- endif %}'
    )
    src = src.replace(
        '{%- if cookiecutter.username_type == "email" %}\n\nfrom .managers import UserManager',
        '{%- if cookiecutter.username_type in ("email", "phone") %}\n\nfrom .managers import UserManager',
    )

    # Fix get_absolute_url to use pk for phone (same as email branch)
    p.write_text(src)
    print("  ✓ phone branch injected into models.py")
PYEOF

# ---------------------------------------------------------------------------
# 3. users/managers.py — add phone manager branch
# ---------------------------------------------------------------------------
echo "→ Patching ${USERS}/managers.py"
python3 - << 'PYEOF'
import pathlib
p = pathlib.Path("{{cookiecutter.project_slug}}/users/managers.py")
src = p.read_text()
if 'username_type == "phone"' in src:
    print("  already patched, skipping")
else:
    phone_manager = '''
{%- elif cookiecutter.username_type == "phone" %}
from django.contrib.auth.base_user import BaseUserManager
from django.utils.translation import gettext_lazy as _


class UserManager(BaseUserManager):
    """
    Custom user model manager where phone number is the unique identifier.
    Phone numbers must be in E.164 format: +[country code][number]
    """

    def create_user(self, phone: str, password: str | None = None, **extra_fields):
        if not phone:
            raise ValueError(_("The Phone Number must be set"))
        user = self.model(phone=phone, **extra_fields)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save()
        return user

    def create_superuser(self, phone: str, password: str | None = None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        if extra_fields.get("is_staff") is not True:
            raise ValueError(_("Superuser must have is_staff=True."))
        if extra_fields.get("is_superuser") is not True:
            raise ValueError(_("Superuser must have is_superuser=True."))
        return self.create_user(phone, password, **extra_fields)
{%- endif %}'''

    # Insert before the final {%- endif %} at end of file
    src = src.rstrip()
    if src.endswith("{%- endif %}"):
        src = src[:-len("{%- endif %}")] + phone_manager + "\n{%- endif %}\n"
    else:
        src += "\n" + phone_manager + "\n"
    p.write_text(src)
    print("  ✓ phone manager injected")
PYEOF

# ---------------------------------------------------------------------------
# 4. users/adapters.py — inject phone adapter methods
# ---------------------------------------------------------------------------
echo "→ Patching ${USERS}/adapters.py"
python3 - << 'PYEOF'
import pathlib
p = pathlib.Path("{{cookiecutter.project_slug}}/users/adapters.py")
src = p.read_text()
if "get_phone" in src:
    print("  already patched, skipping")
else:
    # Insert phone methods right after is_open_for_signup in AccountAdapter
    phone_methods = '''
{%- if cookiecutter.username_type == "phone" %}

    # ------------------------------------------------------------------ #
    # Phone number storage (allauth delegates all model I/O to here)      #
    # ------------------------------------------------------------------ #

    def get_phone(self, user):
        phone = getattr(user, "phone", None)
        if phone:
            return phone, user.phone_verified
        return None

    def set_phone(self, user, phone: str, verified: bool) -> None:
        user.phone = phone
        user.phone_verified = verified
        user.save(update_fields=["phone", "phone_verified"])

    def set_phone_verified(self, user, phone: str) -> None:
        user.phone_verified = True
        user.save(update_fields=["phone_verified"])

    def get_user_by_phone(self, phone: str):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        try:
            return User.objects.get(phone=phone)
        except User.DoesNotExist:
            return None

    # ------------------------------------------------------------------ #
    # SMS sending — implement send_verification_code_sms with your        #
    # chosen provider (see inline comments for Twilio / Vonage examples)  #
    # ------------------------------------------------------------------ #

    def send_verification_code_sms(self, user, phone: str, code: str, **kwargs) -> None:
        """
        Send OTP via SMS. Replace the logger call below with your provider.

        Twilio example:
            from django.conf import settings
            from twilio.rest import Client
            Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN) \\
                .messages.create(
                    body=f"Your {{ cookiecutter.project_name }} code: {code}",
                    from_=settings.TWILIO_PHONE_NUMBER,
                    to=phone,
                )

        Vonage example:
            import vonage
            from django.conf import settings
            vonage.Sms(vonage.Client(key=settings.VONAGE_API_KEY,
                                     secret=settings.VONAGE_API_SECRET)) \\
                .send_message({"from": settings.VONAGE_BRAND_NAME,
                               "to": phone.lstrip("+"),
                               "text": f"Your code: {code}"})
        """
        import logging
        logging.getLogger(__name__).warning(
            "send_verification_code_sms() not implemented. "
            "OTP code for %s: %s",
            phone, code,
        )

    def send_unknown_account_sms(self, phone: str, **kwargs) -> None:
        import logging
        logging.getLogger(__name__).warning(
            "send_unknown_account_sms() called for unregistered phone %s.", phone
        )

{%- endif %}'''

    src = src.replace(
        "        return getattr(self.request, \"allow_signup\", True)",
        "        return getattr(self.request, \"allow_signup\", True)" + phone_methods,
        1,   # only replace the first occurrence (AccountAdapter, not SocialAccountAdapter)
    )
    p.write_text(src)
    print("  ✓ phone adapter methods injected")
PYEOF

# ---------------------------------------------------------------------------
# 5. users/forms.py — add phone branch
# ---------------------------------------------------------------------------
echo "→ Patching ${USERS}/forms.py"
python3 - << 'PYEOF'
import pathlib, re
p = pathlib.Path("{{cookiecutter.project_slug}}/users/forms.py")
src = p.read_text()
if 'username_type == "phone"' in src:
    print("  already patched, skipping")
else:
    src = re.sub(
        r'(\{%- if cookiecutter\.username_type == "email" %\}\nfrom django\.forms import EmailField\n\{%- endif %\})',
        '''{%- if cookiecutter.username_type in ("email", "phone") %}
from django.forms import EmailField
{%- endif %}''',
        src,
    )
    src = src.replace(
        '{%- if cookiecutter.username_type == "email" %}\n        fields = ("email",)',
        '''{%- if cookiecutter.username_type == "email" %}
        fields = ("email",)''',
    )
    # Add phone branch for UserAdminCreationForm
    phone_form = '''
{%- elif cookiecutter.username_type == "phone" %}
        fields = ("phone",)
        error_messages = {
            "phone": {"unique": _("This phone number has already been taken.")},
        }'''
    src = src.replace(
        '{%- endif %}\n\n\nclass UserSignupForm',
        phone_form + '\n{%- endif %}\n\n\nclass UserSignupForm',
        1,
    )
    p.write_text(src)
    print("  ✓ phone branch injected into forms.py")
PYEOF

# ---------------------------------------------------------------------------
# 6. config/settings/base.py — patch allauth block
# ---------------------------------------------------------------------------
echo "→ Patching ${SETTINGS}/base.py"
python3 - << 'PYEOF'
import pathlib, re
p = pathlib.Path("{{cookiecutter.project_slug}}/config/settings/base.py")
src = p.read_text()
if 'username_type == "phone"' in src:
    print("  already patched, skipping")
else:
    phone_settings = '''
{%- elif cookiecutter.username_type == "phone" %}
ACCOUNT_LOGIN_METHODS = {"phone"}
ACCOUNT_SIGNUP_FIELDS = ["phone*"]
ACCOUNT_PHONE_VERIFICATION_ENABLED = True
ACCOUNT_PHONE_VERIFICATION_SUPPORTS_RESEND = True
ACCOUNT_PHONE_VERIFICATION_TIMEOUT = env.int(
    "ACCOUNT_PHONE_VERIFICATION_TIMEOUT", default=900
)'''

    # Insert phone branch after the email branch in ACCOUNT_LOGIN_METHODS block
    src = re.sub(
        r'(\{%- elif cookiecutter\.username_type == "email" %\}\nACCOUNT_LOGIN_METHODS = \{"email"\}\nACCOUNT_SIGNUP_FIELDS = \["email\*", "password1\*", "password2\*"\])',
        lambda m: m.group(0) + phone_settings,
        src,
    )

    # Also add SMS provider comments block at end of allauth section (before closing endif)
    sms_comments = '''
{%- if cookiecutter.username_type == "phone" %}
# SMS provider env vars — fill in .envs/.local/.django
# TWILIO_ACCOUNT_SID = env("TWILIO_ACCOUNT_SID", default="")
# TWILIO_AUTH_TOKEN  = env("TWILIO_AUTH_TOKEN",  default="")
# TWILIO_PHONE_NUMBER = env("TWILIO_PHONE_NUMBER", default="")
{%- endif %}'''

    src = src.replace(
        'SOCIALACCOUNT_FORMS = {"signup": "{{ cookiecutter.project_slug }}.users.forms.UserSocialSignupForm"}',
        'SOCIALACCOUNT_FORMS = {"signup": "{{ cookiecutter.project_slug }}.users.forms.UserSocialSignupForm"}' + sms_comments,
    )
    p.write_text(src)
    print("  ✓ phone settings block injected into base.py")
PYEOF

# ---------------------------------------------------------------------------
# 7. hooks/post_gen_project.py — update managers.py removal condition
# ---------------------------------------------------------------------------
echo "→ Patching hooks/post_gen_project.py"
python3 - << 'PYEOF'
import pathlib, re
p = pathlib.Path("hooks/post_gen_project.py")
src = p.read_text()

if '"phone"' in src:
    print("  already patched, skipping")
else:
    # Fix managers.py removal to preserve it for phone too
    src = src.replace(
        'if "{{ cookiecutter.username_type }}" != "email":',
        'if "{{ cookiecutter.username_type }}" not in ("email", "phone"):',
    )

    # Add removal of phone templates dir when NOT phone auth
    phone_cleanup = '''
    if "{{ cookiecutter.username_type }}" != "phone":
        # Remove phone-specific allauth templates
        import shutil as _shutil
        _phone_tpl = Path("{{ cookiecutter.project_slug }}/templates/account/phone")
        if _phone_tpl.exists():
            _shutil.rmtree(_phone_tpl)
'''
    # Insert just after the managers.py removal block
    src = src.replace(
        'if "{{ cookiecutter.username_type }}" not in ("email", "phone"):\n        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))',
        'if "{{ cookiecutter.username_type }}" not in ("email", "phone"):\n        remove_file(Path("{{ cookiecutter.project_slug }}/users/managers.py"))' + phone_cleanup,
    )
    p.write_text(src)
    print("  ✓ hook updated")
PYEOF

# ---------------------------------------------------------------------------
# 8. Copy phone-specific NEW files into the template tree
# ---------------------------------------------------------------------------
echo "→ Copying new template files"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# OTP verification template
mkdir -p "${SLUG}/templates/account/phone"
cp "${SCRIPT_DIR}/template/templates/account/phone/verification_code.html" \
   "${SLUG}/templates/account/phone/verification_code.html"
cp "${SCRIPT_DIR}/template/templates/account/phone/signup.html" \
   "${SLUG}/templates/account/phone/signup.html"

# Updated login template with phone note
cp "${SCRIPT_DIR}/template/templates/account/login.html" \
   "${SLUG}/templates/account/login.html"

# users/tests/factories.py — only if phone branch not yet there
if ! grep -q 'username_type == "phone"' "${USERS}/tests/factories.py" 2>/dev/null; then
    cp "${SCRIPT_DIR}/template/users/tests/factories.py" \
       "${USERS}/tests/factories.py"
    echo "  ✓ factories.py updated"
fi

# users/tests/test_adapters.py (new file)
if [ ! -f "${USERS}/tests/test_adapters.py" ]; then
    cp "${SCRIPT_DIR}/template/users/tests/test_adapters.py" \
       "${USERS}/tests/test_adapters.py"
    echo "  ✓ test_adapters.py added"
fi

# users/tests/test_models.py phone branch (append if missing)
if ! grep -q 'username_type == "phone"' "${USERS}/tests/test_models.py" 2>/dev/null; then
    cat "${SCRIPT_DIR}/template/users/tests/test_models.py" >> \
        "${USERS}/tests/test_models.py"
    echo "  ✓ test_models.py phone tests appended"
fi

# users/urls.py — update slug_field for phone (pk-based like email)
python3 - << 'PYEOF'
import pathlib, re
p = pathlib.Path("{{cookiecutter.project_slug}}/users/urls.py")
if not p.exists():
    print("  urls.py not found, skipping")
else:
    src = p.read_text()
    if 'username_type == "username"' in src:
        print("  urls.py already conditional, skipping")
    else:
        src = src.replace(
            'path("<str:username>/", view=user_detail_view, name="detail"),',
            '''{%- if cookiecutter.username_type == "username" %}
    path("<str:username>/", view=user_detail_view, name="detail"),
{%- else %}
    path("<int:pk>/", view=user_detail_view, name="detail"),
{%- endif %}''',
        )
        p.write_text(src)
        print("  ✓ urls.py patched to support pk-based URLs for phone/email")
PYEOF

# Migration placeholder for phone (rendered as empty for other types)
MIGRATIONS="${SLUG}/users/migrations"
if [ ! -f "${MIGRATIONS}/0001_initial.py" ] || \
   ! grep -q 'username_type == "phone"' "${MIGRATIONS}/0001_initial.py" 2>/dev/null; then
    mkdir -p "$MIGRATIONS"
    cp "${SCRIPT_DIR}/template/users/migrations/0001_initial.py" \
       "${MIGRATIONS}/0001_initial.py"
    echo "  ✓ migration 0001 placeholder updated"
fi

# ---------------------------------------------------------------------------
# 9. Stage everything
# ---------------------------------------------------------------------------
echo "→ Staging changes"
git add -A

echo ""
echo "============================================================"
echo "  Branch '$BRANCH' ready!"
echo ""
echo "  Review staged changes:"
echo "    git diff --cached"
echo ""
echo "  Commit:"
echo "    git commit -m 'feat: add phone+OTP authentication option'"
echo ""
echo "  Push to your fork:"
echo "    git push -u origin $BRANCH"
echo ""
echo "  Then open a PR from:"
echo "    https://github.com/Ali-Fani/cookiecutter-django/compare/$BRANCH"
echo "============================================================"
